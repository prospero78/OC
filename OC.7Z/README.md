﻿# OC
Oberon-07 Compiler for .Net (stage 1)

## License
BSD-2

## About
The project is aimed at creating a compiler "Oberon-07" for the .Net
platform. Theoretically, it should compile under.
Mono.
Also, this version of Oberon-07 will support multiple national
languages through a language settings file.
This is the first phase of the compiler (stage 1), the project is being developed
for VisualBasic for .Net (vers 4.5).
The second phase of the compiler will be rewritten on Oberon-07 itself (stage 2).
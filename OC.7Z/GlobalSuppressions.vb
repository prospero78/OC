﻿
' This file is used by Code Analysis to maintain SuppressMessage 
' attributes that are applied to this project.
' Project-level suppressions either have no target or are given 
' a specific target and scoped to a namespace, type, member, etc.

<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="type", Target:="~T:OC.окнГлавное")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="member", Target:="~M:oc.пиОк.туКоорд.цСтр_Уст(System.Int32)")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="member", Target:="~P:oc.пиОк.туКоорд.цСтр")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="member", Target:="~M:oc.пиОк.туКоорд.цПоз_Уст(System.Int32)")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="member", Target:="~P:oc.пиОк.туКоорд.цПоз")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="member", Target:="~P:oc.пиОк.тСлова.уПервЛекс")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="type", Target:="~T:oc.пиОк.туСлово")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="type", Target:="~T:oc.пиОк.туКоорд")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="type", Target:="~T:oc.пиОк.туИсход")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="type", Target:="~T:oc.пиОк.тСлова")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="member", Target:="~M:My.My.туКоорд.цСтр_Уст(System.Int32)")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="member", Target:="~P:My.My.туКоорд.цСтр")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="member", Target:="~M:My.My.туКоорд.цПоз_Уст(System.Int32)")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="member", Target:="~P:My.My.тСлова.уПервЛекс")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="type", Target:="~T:My.My.туКоорд")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="type", Target:="~T:My.My.туСлово")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="member", Target:="~P:My.My.тСлова.длина")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="member", Target:="~P:My.My.туИсход.длина")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="member", Target:="~P:My.My.туИсход.лит")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="member", Target:="~P:My.My.туИсход.лит2")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="type", Target:="~T:My.My.тСлова")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="type", Target:="~T:My.My.туИсход")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="member", Target:="~M:My.My.туЗвено.уПред_Уст(My.My.туЗвено)")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="member", Target:="~M:My.My.туЗвено.уСлед_Уст(My.My.туЗвено)")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="member", Target:="~P:My.My.clsCount.val")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="member", Target:="~P:My.My.туЗвено.уПред")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="member", Target:="~P:My.My.туЗвено.уСлед")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="member", Target:="~P:My.My.туЗвено.цВсего")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="member", Target:="~P:My.My.туИмя.strVal")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="type", Target:="~T:My.My.clsArgs")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="type", Target:="~T:My.My.clsConst")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="type", Target:="~T:My.My.clsCount")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="type", Target:="~T:My.My.clsImport")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="type", Target:="~T:My.My.clsModType")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="type", Target:="~T:My.My.clsModule")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="type", Target:="~T:My.My.clsType")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="type", Target:="~T:My.My.clsTypeArray")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="type", Target:="~T:My.My.clsTypeMember")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="type", Target:="~T:My.My.clsTypeRecord")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="type", Target:="~T:My.My.клсАнализ")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="type", Target:="~T:My.My.туЗвено")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="type", Target:="~T:My.My.туИмя")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="type", Target:="~T:My.My.туЦепь")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="member", Target:="~M:My.окнГлавное.окнГлавное_Load(System.Object,System.EventArgs)")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="member", Target:="~M:My.окнГлавное.btnClear_Click(System.Object,System.EventArgs)")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="member", Target:="~M:My.окнГлавное.btnCompile_Click(System.Object,System.EventArgs)")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="member", Target:="~M:My.окнГлавное.btnStep_Click(System.Object,System.EventArgs)")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="member", Target:="~M:My.туКоорд.цПоз_Уст(System.Int32)")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="member", Target:="~M:My.туКоорд.цСтр_Уст(System.Int32)")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="member", Target:="~P:My.тСлова.длина")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="member", Target:="~P:My.тСлова.уПервЛекс")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="member", Target:="~P:My.туИсход.длина")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="member", Target:="~P:My.туИсход.лит")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="member", Target:="~P:My.туИсход.лит2")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="member", Target:="~P:My.туКоорд.цПоз")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="member", Target:="~P:My.туКоорд.цСтр")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="member", Target:="~P:My.туСлово.стрСлово")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="type", Target:="~T:My.тСлова")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="type", Target:="~T:My.туИсход")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="type", Target:="~T:My.туКоорд")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Стиль", "IDE1006:Стили именования", Justification:="<Ожидание>", Scope:="type", Target:="~T:My.туСлово")>
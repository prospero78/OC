﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' Общие сведения об этой сборке предоставляются следующим набором 
' атрибутов. Отредактируйте значения этих атрибутов, чтобы изменить
' общие сведения об этой сборке.

' Проверьте значения атрибутов сборки

<Assembly: AssemblyTitle("oc.exe")>
<Assembly: AssemblyDescription("Компилятор Оберон-07 для .Net. Распорстраняется под лицензией BSD-2. Возможно любое использование без предоставления гарантий.")>
<Assembly: AssemblyCompany("КБК Техника")>
<Assembly: AssemblyProduct("oc.exe")>
<Assembly: AssemblyCopyright("КБК Техника")>
<Assembly: AssemblyTrademark("BSD-2")>

<Assembly: ComVisible(False)>

'Следующий GUID служит для идентификации библиотеки типов, если этот проект будет видимым для COM
<Assembly: Guid("53e2d11c-ba8c-42b5-9c16-b592b2e96ad2")>

' Сведения о версии сборки состоят из следующих четырех значений:
'
'      Основной номер версии
'      Дополнительный номер версии 
'   Номер сборки
'      Редакция
'
' Можно задать все значения или принять номера сборки и редакции по умолчанию 
' используя "*", как показано ниже:

<Assembly: AssemblyVersion("0.0.90.0")>
<Assembly: AssemblyFileVersion("0.0.90.0")>
